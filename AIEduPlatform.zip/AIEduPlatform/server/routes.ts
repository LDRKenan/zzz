import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { 
  insertCourseSchema, 
  insertCommunitySchema, 
  insertPostSchema,
  insertCompetitionSchema
} from "@shared/schema";
import openai from './openai'; // Assuming openai is configured elsewhere

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Course routes
  app.get("/api/courses", async (req, res) => {
    const courses = await storage.getCourses();
    res.json(courses);
  });

  app.get("/api/courses/:id", async (req, res) => {
    const course = await storage.getCourse(parseInt(req.params.id));
    if (!course) {
      return res.status(404).send("Course not found");
    }
    res.json(course);
  });

  app.post("/api/courses", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "teacher") {
      return res.status(403).send("Only teachers can create courses");
    }

    const parsed = insertCourseSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json(parsed.error);
    }

    const course = await storage.createCourse({
      ...parsed.data,
      instructorId: req.user.id,
    });
    res.status(201).json(course);
  });

  // Progress routes
  app.get("/api/progress", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }
    const progress = await storage.getProgress(req.user.id);
    res.json(progress);
  });

  app.post("/api/progress/:courseId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    const courseId = parseInt(req.params.courseId);
    const course = await storage.getCourse(courseId);
    if (!course) {
      return res.status(404).send("Course not found");
    }

    const progress = await storage.updateProgress(
      req.user.id,
      courseId,
      req.body.completed === true
    );

    // Award points for completing a course
    if (req.body.completed) {
      await storage.updateUserPoints(req.user.id, 100);
    }

    res.json(progress);
  });

  // Community routes
  app.get("/api/communities", async (req, res) => {
    const communities = await storage.getCommunities();
    res.json(communities);
  });

  app.get("/api/communities/:id", async (req, res) => {
    const community = await storage.getCommunity(parseInt(req.params.id));
    if (!community) {
      return res.status(404).send("Community not found");
    }
    res.json(community);
  });

  app.post("/api/communities", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    const parsed = insertCommunitySchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json(parsed.error);
    }

    const community = await storage.createCommunity({
      ...parsed.data,
      creatorId: req.user.id,
    });
    res.status(201).json(community);
  });

  // Posts routes
  app.get("/api/communities/:communityId/posts", async (req, res) => {
    const posts = await storage.getPosts(parseInt(req.params.communityId));
    res.json(posts);
  });

  app.post("/api/communities/:communityId/posts", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    const parsed = insertPostSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json(parsed.error);
    }

    const post = await storage.createPost({
      ...parsed.data,
      communityId: parseInt(req.params.communityId),
      authorId: req.user.id,
    });
    res.status(201).json(post);
  });

  // Competition routes
  app.get("/api/competitions", async (req, res) => {
    const competitions = await storage.getCompetitions();
    res.json(competitions);
  });

  app.get("/api/competitions/:id", async (req, res) => {
    const competition = await storage.getCompetition(parseInt(req.params.id));
    if (!competition) {
      return res.status(404).send("Competition not found");
    }

app.post("/api/upload/video", async (req, res) => {
  if (!req.isAuthenticated() || req.user.role !== "teacher") {
    return res.status(403).send("Only teachers can upload videos");
  }
  
  try {
    if (!req.files || !req.files.video) {
      return res.status(400).send("No video file uploaded");
    }

    const file = req.files.video;
    const path = await storage.uploadVideo(file.data, file.name);
    
    res.status(201).json({ 
      message: "Video uploaded successfully",
      path: path 
    });
  } catch (error) {
    console.error("Failed to upload video:", error);
    res.status(500).send("Failed to upload video");
  }
});

app.post("/api/upload/ebook", async (req, res) => {
  if (!req.isAuthenticated() || req.user.role !== "teacher") {
    return res.status(403).send("Only teachers can upload ebooks");
  }
  
  try {
    if (!req.files || !req.files.ebook) {
      return res.status(400).send("No ebook file uploaded");
    }

    const file = req.files.ebook;
    const path = await storage.uploadEbook(file.data, file.name);
    
    res.status(201).json({
      message: "Ebook uploaded successfully",
      path: path
    });
  } catch (error) {
    console.error("Failed to upload ebook:", error);
    res.status(500).send("Failed to upload ebook");
  }
});

app.post("/api/upload/ebook", async (req, res) => {
  if (!req.isAuthenticated() || req.user.role !== "teacher") {
    return res.status(403).send("Only teachers can upload ebooks");
  }
  try {
    // E-kitap yükleme işlemi burada yapılacak
    res.status(201).json({ message: "Ebook uploaded successfully" });
  } catch (error) {
    console.error("Failed to upload ebook:", error);
    res.status(500).send("Failed to upload ebook");
  }
});

    res.json(competition);
  });

  app.post("/api/competitions", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "teacher") {
      return res.status(403).send("Only teachers can create competitions");
    }

    const parsed = insertCompetitionSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json(parsed.error);
    }

    const competition = await storage.createCompetition({
      ...parsed.data,
      creatorId: req.user.id,
    });
    res.status(201).json(competition);
  });

  app.post("/api/competitions/:id/submit", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    const competitionId = parseInt(req.params.id);
    const competition = await storage.getCompetition(competitionId);
    if (!competition) {
      return res.status(404).send("Competition not found");
    }

    if (new Date() > competition.endDate) {
      return res.status(400).send("Competition has ended");
    }

    const entry = await storage.submitCompetitionEntry({
      competitionId,
      userId: req.user.id,
      submission: req.body.submission,
      score: null,
    });
    res.status(201).json(entry);
  });

  app.get("/api/competitions/:id/leaderboard", async (req, res) => {
    const entries = await storage.getCompetitionEntries(parseInt(req.params.id));
    res.json(entries);
  });

  // Add this to the existing routes in registerRoutes function
  app.post("/api/ai/chat", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send("Unauthorized");
    }

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a helpful educational AI assistant. Provide clear, informative responses to help students learn effectively. Respond in Turkish language.",
          },
          {
            role: "user",
            content: req.body.message,
          },
        ],
      });

      res.json({ message: response.choices[0].message.content });
    } catch (error) {
      console.error("OpenAI API error:", error);
      res.status(500).send("Failed to get AI response");
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}