import { 
  InsertUser, User, Course, Progress, Community, Post, 
  Competition, CompetitionEntry, InsertCommunity, InsertPost,
  InsertCompetition
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // File management
  uploadVideo(file: Buffer, filename: string): Promise<string>;
  uploadEbook(file: Buffer, filename: string): Promise<string>;
  
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, points: number): Promise<User>;

  // Course management
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: Omit<Course, "id" | "createdAt">): Promise<Course>;

  // Progress tracking
  getProgress(userId: number): Promise<Progress[]>;
  updateProgress(userId: number, courseId: number, completed: boolean): Promise<Progress>;

  // Community features
  createCommunity(community: InsertCommunity): Promise<Community>;
  getCommunities(): Promise<Community[]>;
  getCommunity(id: number): Promise<Community | undefined>;

  // Posts
  createPost(post: InsertPost & { authorId: number }): Promise<Post>;
  getPosts(communityId: number): Promise<Post[]>;

  // Competitions
  createCompetition(competition: InsertCompetition): Promise<Competition>;
  getCompetitions(): Promise<Competition[]>;
  getCompetition(id: number): Promise<Competition | undefined>;
  submitCompetitionEntry(entry: Omit<CompetitionEntry, "id" | "submittedAt">): Promise<CompetitionEntry>;
  getCompetitionEntries(competitionId: number): Promise<CompetitionEntry[]>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private uploads: Map<string, Buffer>;
  private users: Map<number, User>;
  
  async uploadVideo(file: Buffer, filename: string): Promise<string> {
    const path = `videos/${filename}`;
    this.uploads.set(path, file);
    return path;
  }

  async uploadEbook(file: Buffer, filename: string): Promise<string> {
    const path = `ebooks/${filename}`;
    this.uploads.set(path, file);
    return path;
  }
  private courses: Map<number, Course>;
  private progress: Map<string, Progress>;
  private communities: Map<number, Community>;
  private posts: Map<number, Post>;
  private competitions: Map<number, Competition>;
  private competitionEntries: Map<number, CompetitionEntry>;
  sessionStore: session.Store;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.progress = new Map();
    this.communities = new Map();
    this.posts = new Map();
    this.competitions = new Map();
    this.competitionEntries = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = {
      ...insertUser,
      id,
      points: 0,
      role: insertUser.role || "student"
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserPoints(userId: number, points: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");

    const updatedUser = { ...user, points: user.points + points };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Course management
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async createCourse(course: Omit<Course, "id" | "createdAt">): Promise<Course> {
    const id = this.currentId++;
    const newCourse: Course = {
      ...course,
      id,
      createdAt: new Date(),
    };
    this.courses.set(id, newCourse);
    return newCourse;
  }

  // Progress tracking
  async getProgress(userId: number): Promise<Progress[]> {
    return Array.from(this.progress.values()).filter(p => p.userId === userId);
  }

  async updateProgress(userId: number, courseId: number, completed: boolean): Promise<Progress> {
    const key = `${userId}-${courseId}`;
    const existing = this.progress.get(key);
    const progress: Progress = {
      id: existing?.id || this.currentId++,
      userId,
      courseId,
      completed,
      lastAccessed: new Date(),
      aiRecommendations: existing?.aiRecommendations || null,
    };
    this.progress.set(key, progress);
    return progress;
  }

  // Community features
  async createCommunity(community: InsertCommunity): Promise<Community> {
    const id = this.currentId++;
    const newCommunity: Community = {
      ...community,
      id,
      createdAt: new Date(),
    };
    this.communities.set(id, newCommunity);
    return newCommunity;
  }

  async getCommunities(): Promise<Community[]> {
    return Array.from(this.communities.values());
  }

  async getCommunity(id: number): Promise<Community | undefined> {
    return this.communities.get(id);
  }

  // Posts
  async createPost(post: InsertPost & { authorId: number }): Promise<Post> {
    const id = this.currentId++;
    const newPost: Post = {
      ...post,
      id,
      createdAt: new Date(),
    };
    this.posts.set(id, newPost);
    return newPost;
  }

  async getPosts(communityId: number): Promise<Post[]> {
    return Array.from(this.posts.values())
      .filter(post => post.communityId === communityId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Competitions
  async createCompetition(competition: InsertCompetition): Promise<Competition> {
    const id = this.currentId++;
    const newCompetition: Competition = {
      ...competition,
      id,
    };
    this.competitions.set(id, newCompetition);
    return newCompetition;
  }

  async getCompetitions(): Promise<Competition[]> {
    return Array.from(this.competitions.values())
      .sort((a, b) => b.startDate.getTime() - a.startDate.getTime());
  }

  async getCompetition(id: number): Promise<Competition | undefined> {
    return this.competitions.get(id);
  }

  async submitCompetitionEntry(entry: Omit<CompetitionEntry, "id" | "submittedAt">): Promise<CompetitionEntry> {
    const id = this.currentId++;
    const newEntry: CompetitionEntry = {
      ...entry,
      id,
      submittedAt: new Date(),
    };
    this.competitionEntries.set(id, newEntry);
    return newEntry;
  }

  async getCompetitionEntries(competitionId: number): Promise<CompetitionEntry[]> {
    return Array.from(this.competitionEntries.values())
      .filter(entry => entry.competitionId === competitionId)
      .sort((a, b) => (b.score || 0) - (a.score || 0));
  }
}

export const storage = new MemStorage();