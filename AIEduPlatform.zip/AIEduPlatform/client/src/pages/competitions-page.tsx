
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Trophy, Timer, Plus, Globe, Flag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Competition } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function CompetitionsPage() {
  const { user } = useAuth();
  const { data: competitions } = useQuery<Competition[]>({
    queryKey: ["/api/competitions"],
  });

  const ageGroups = [
    { min: 11, max: 12 },
    { min: 12, max: 13 },
    { min: 13, max: 14 },
    { min: 14, max: 15 },
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Trophy className="h-6 w-6 text-primary" />
          <h1 className="text-3xl font-bold">Yarışmalar</h1>
        </div>
        {user?.role === "teacher" && (
          <Button className="bg-gradient-to-r from-primary to-primary/80">
            <Plus className="h-4 w-4 mr-2" />
            Yeni Yarışma Oluştur
          </Button>
        )}
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">Tüm Yarışmalar</TabsTrigger>
          {ageGroups.map(group => (
            <TabsTrigger key={`${group.min}-${group.max}`} value={`${group.min}-${group.max}`}>
              {group.min}-{group.max} Yaş
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Globe className="h-5 w-5" /> Küresel Sıralama
              </h2>
              <div className="space-y-4">
                {competitions?.filter(c => c.scope === "global")
                  .map((competition) => (
                    <CompetitionCard key={competition.id} competition={competition} />
                  ))}
              </div>
            </div>
            <div>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Flag className="h-5 w-5" /> Ulusal Sıralama
              </h2>
              <div className="space-y-4">
                {competitions?.filter(c => c.scope === "national")
                  .map((competition) => (
                    <CompetitionCard key={competition.id} competition={competition} />
                  ))}
              </div>
            </div>
          </div>
        </TabsContent>

        {ageGroups.map(group => (
          <TabsContent key={`${group.min}-${group.max}`} value={`${group.min}-${group.max}`}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Globe className="h-5 w-5" /> Küresel Sıralama ({group.min}-{group.max} Yaş)
                </h2>
                <div className="space-y-4">
                  {competitions?.filter(c => 
                    c.scope === "global" && 
                    c.ageGroupMin === group.min && 
                    c.ageGroupMax === group.max
                  ).map((competition) => (
                    <CompetitionCard key={competition.id} competition={competition} />
                  ))}
                </div>
              </div>
              <div>
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Flag className="h-5 w-5" /> Ulusal Sıralama ({group.min}-{group.max} Yaş)
                </h2>
                <div className="space-y-4">
                  {competitions?.filter(c => 
                    c.scope === "national" && 
                    c.ageGroupMin === group.min && 
                    c.ageGroupMax === group.max
                  ).map((competition) => (
                    <CompetitionCard key={competition.id} competition={competition} />
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

function CompetitionCard({ competition }: { competition: Competition }) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <CardTitle>{competition.title}</CardTitle>
        <CardDescription>{competition.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Timer className="h-4 w-4" />
            <span>Bitiş: {new Date(competition.endDate).toLocaleDateString('tr-TR')}</span>
          </div>
          <div className="text-sm text-muted-foreground">
            Yaş Grubu: {competition.ageGroupMin}-{competition.ageGroupMax}
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button className="w-full bg-gradient-to-r from-primary to-primary/80">
          Yarışmaya Katıl
        </Button>
      </CardFooter>
    </Card>
  );
}
