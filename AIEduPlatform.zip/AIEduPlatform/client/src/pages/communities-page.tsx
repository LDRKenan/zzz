import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Plus } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Community } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function CommunitiesPage() {
  const { toast } = useToast();
  const { data: communities } = useQuery<Community[]>({
    queryKey: ["/api/communities"],
  });

  const createCommunityMutation = useMutation({
    mutationFn: async (data: { name: string; description: string }) => {
      const res = await apiRequest("POST", "/api/communities", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/communities"] });
      toast({
        title: "Başarılı",
        description: "Topluluk başarıyla oluşturuldu.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Hata",
        description: "Topluluk oluşturulurken bir hata oluştu.",
        variant: "destructive",
      });
    },
  });

  const handleCreateCommunity = () => {
    // This is a temporary solution - you should create a proper form dialog
    const name = prompt("Topluluk adı:");
    const description = prompt("Topluluk açıklaması:");

    if (name && description) {
      createCommunityMutation.mutate({ name, description });
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="h-6 w-6 text-primary" />
          <h1 className="text-3xl font-bold">Topluluklar</h1>
        </div>
        <Button 
          className="bg-gradient-to-r from-primary to-primary/80"
          onClick={handleCreateCommunity}
          disabled={createCommunityMutation.isPending}
        >
          <Plus className="h-4 w-4 mr-2" />
          Yeni Topluluk Oluştur
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {communities?.map((community) => (
          <Card key={community.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>{community.name}</CardTitle>
              <CardDescription>{community.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="w-full">Topluluğa Katıl</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}