import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Video, Upload } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";

export default function CreateVideoPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  if (user?.role !== "teacher") {
    setLocation("/");
    return null;
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle video upload here.  This requires backend integration and is not provided in the original or edited code.
    console.log("Video upload form submitted");
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-2">
        <Video className="h-6 w-6 text-primary" />
        <h1 className="text-3xl font-bold">Video İçeriği Oluştur</h1>
      </div>

      <Card className="bg-gradient-to-br from-primary/5 to-primary/10">
        <CardHeader>
          <CardTitle>Video Yükle</CardTitle>
          <CardDescription>
            Öğrenciler için eğitici video içeriği oluşturun
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border-2 border-dashed rounded-lg p-12 text-center">
            <form onSubmit={handleSubmit} encType="multipart/form-data">
              <input type="file" name="video" accept="video/*" />
              <button type="submit" className="bg-primary text-white px-4 py-2 rounded">
                Upload Video
              </button>
            </form>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Video Detayları</CardTitle>
          <CardDescription>
            Video hakkında bilgi ekleyin
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">Başlık</label>
            <input
              type="text"
              className="w-full mt-1 rounded-md border border-input bg-background px-3 py-2"
              placeholder="Video başlığı"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Açıklama</label>
            <textarea
              className="w-full mt-1 rounded-md border border-input bg-background px-3 py-2"
              rows={4}
              placeholder="Video açıklaması"
            />
          </div>
          <Button className="w-full">Yükle ve Yayınla</Button>
        </CardContent>
      </Card>
    </div>
  );
}