import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BookOpen, BookPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

export default function LibraryPage() {
  const { user } = useAuth();

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BookOpen className="h-6 w-6 text-primary" />
          <h1 className="text-3xl font-bold">E-Kitap Kütüphanesi</h1>
        </div>
        {user?.role === "teacher" && (
          <Button className="bg-gradient-to-r from-primary to-primary/80">
            <BookPlus className="h-4 w-4 mr-2" />
            Yeni E-Kitap Yükle
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {/* Placeholder cards for demonstration */}
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="hover:shadow-lg transition-shadow">
            <div className="aspect-[3/4] bg-gradient-to-br from-primary/5 to-primary/10 rounded-t-lg" />
            <CardHeader>
              <CardTitle className="text-lg">Örnek E-Kitap {i}</CardTitle>
              <CardDescription>Yazar Adı</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="w-full">Oku</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
