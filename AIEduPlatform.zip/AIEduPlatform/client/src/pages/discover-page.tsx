import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Compass, Users, Trophy, BookOpen, Brain } from "lucide-react";
import { Course, Community, Competition } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function DiscoverPage() {
  const { data: courses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  return (
    <div className="space-y-8">
      {/* Video Feed Section */}
      <div className="bg-gradient-to-r from-primary/5 to-primary/10 rounded-lg p-6">
        <h2 className="text-2xl font-bold mb-4">Öne Çıkan Videolar</h2>
        <ScrollArea className="h-[500px] rounded-md border p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Placeholder video cards */}
            {Array.from({ length: 9 }).map((_, i) => (
              <Card key={i} className="overflow-hidden hover:shadow-lg transition-all">
                <div className="aspect-video bg-gradient-to-br from-primary/20 to-primary/10" />
                <CardContent className="p-4">
                  <h3 className="font-semibold">Video Başlığı {i + 1}</h3>
                  <p className="text-sm text-muted-foreground">Öğretmen Adı</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Quick Access Section */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Link href="/ai-learning">
          <a>
            <Card className="hover:shadow-lg transition-all bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950">
              <CardContent className="pt-6">
                <Brain className="h-8 w-8 mb-2 text-primary" />
                <h2 className="font-semibold">AI Destekli Öğrenme</h2>
                <p className="text-sm text-muted-foreground">
                  Kişiselleştirilmiş öğrenme deneyimi
                </p>
              </CardContent>
            </Card>
          </a>
        </Link>

        <Link href="/communities">
          <a>
            <Card className="hover:shadow-lg transition-all bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950">
              <CardContent className="pt-6">
                <Users className="h-8 w-8 mb-2 text-primary" />
                <h2 className="font-semibold">Topluluklar</h2>
                <p className="text-sm text-muted-foreground">
                  Öğrenme topluluklarına katıl
                </p>
              </CardContent>
            </Card>
          </a>
        </Link>

        <Link href="/competitions">
          <a>
            <Card className="hover:shadow-lg transition-all bg-gradient-to-br from-cyan-50 to-teal-50 dark:from-cyan-950 dark:to-teal-950">
              <CardContent className="pt-6">
                <Trophy className="h-8 w-8 mb-2 text-primary" />
                <h2 className="font-semibold">Yarışmalar</h2>
                <p className="text-sm text-muted-foreground">
                  Yeteneklerini göster
                </p>
              </CardContent>
            </Card>
          </a>
        </Link>

        <Link href="/library">
          <a>
            <Card className="hover:shadow-lg transition-all bg-gradient-to-br from-teal-50 to-emerald-50 dark:from-teal-950 dark:to-emerald-950">
              <CardContent className="pt-6">
                <BookOpen className="h-8 w-8 mb-2 text-primary" />
                <h2 className="font-semibold">E-Kitap Kütüphanesi</h2>
                <p className="text-sm text-muted-foreground">
                  Dijital kaynaklara eriş
                </p>
              </CardContent>
            </Card>
          </a>
        </Link>
      </div>
      {courses && courses.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-2xl font-bold">Öne Çıkan Dersler</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {courses.slice(0, 3).map((course) => (
              <Card key={course.id}>
                <CardHeader>
                  <CardTitle>{course.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{course.description}</p>
                  <Button className="mt-4" variant="outline">
                    Derse Git
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      { /*This part was removed in the edited code, but it's important to keep it*/ }
    </div>
  );
}