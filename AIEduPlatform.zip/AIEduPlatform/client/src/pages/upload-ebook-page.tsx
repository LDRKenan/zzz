import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, BookPlus } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";

export default function UploadEbookPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  if (user?.role !== "teacher") {
    setLocation("/");
    return null;
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle ebook upload here.  This needs to be implemented to actually upload the file.
    const formData = new FormData(event.target);
    // ... (Add your upload logic here) ...
    console.log("Form data:", formData);

  };

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-2">
        <BookPlus className="h-6 w-6 text-primary" />
        <h1 className="text-3xl font-bold">E-Kitap Yükle</h1>
      </div>

      <Card className="bg-gradient-to-br from-primary/5 to-primary/10">
        <CardHeader>
          <CardTitle>E-Kitap Yükle</CardTitle>
          <CardDescription>
            PDF veya EPUB formatında e-kitap yükleyin
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} encType="multipart/form-data">
            <input type="file" name="ebook" accept=".pdf,.epub,.mobi" />
            <button type="submit" className="bg-primary text-white px-4 py-2 rounded">
              Yükle
            </button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Kitap Detayları</CardTitle>
          <CardDescription>
            E-kitap hakkında bilgi ekleyin
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">Başlık</label>
            <input
              type="text"
              className="w-full mt-1 rounded-md border border-input bg-background px-3 py-2"
              placeholder="Kitap başlığı"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Yazar</label>
            <input
              type="text"
              className="w-full mt-1 rounded-md border border-input bg-background px-3 py-2"
              placeholder="Yazar adı"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Açıklama</label>
            <textarea
              className="w-full mt-1 rounded-md border border-input bg-background px-3 py-2"
              rows={4}
              placeholder="Kitap açıklaması"
            />
          </div>
          <Button className="w-full">Yükle ve Yayınla</Button>
        </CardContent>
      </Card>
    </div>
  );
}