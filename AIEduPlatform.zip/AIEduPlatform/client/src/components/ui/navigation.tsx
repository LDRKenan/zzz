import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Button } from "./button";
import { Avatar, AvatarFallback } from "./avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./dropdown-menu";
import {
  Compass,
  Brain,
  Users,
  Trophy,
  BookOpen,
  Video,
  Upload,
  User,
  LogOut,
  MenuIcon,
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "./sheet";

export default function Navigation() {
  const { user, logoutMutation } = useAuth();

  if (!user) {
    return null;
  }

  const navigationItems = [
    { href: "/discover", icon: Compass, label: "Keşfet" },
    { href: "/ai-learning", icon: Brain, label: "AI Destekli Öğrenme" },
    { href: "/communities", icon: Users, label: "Topluluklar" },
    { href: "/competitions", icon: Trophy, label: "Yarışmalar" },
    { href: "/library", icon: BookOpen, label: "E-Kitap Kütüphanesi" },
  ];

  const teacherItems = user.role === "teacher" ? [
    { href: "/create-video", icon: Video, label: "Video İçeriği Oluştur" },
    { href: "/upload-ebook", icon: Upload, label: "E-Kitap Yükle" },
  ] : [];

  const allItems = [...navigationItems, ...teacherItems];

  return (
    <nav className="border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/">
            <a className="text-xl font-bold">Zeuph</a>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            {allItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </a>
              </Link>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* Mobile Navigation */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <MenuIcon className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <div className="flex flex-col gap-4 mt-8">
                {allItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <a className="flex items-center gap-2 text-sm font-medium">
                      <item.icon className="h-4 w-4" />
                      {item.label}
                    </a>
                  </Link>
                ))}
              </div>
            </SheetContent>
          </Sheet>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <Avatar className="h-8 w-8">
                  <AvatarFallback>
                    {user.username.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuItem asChild>
                <Link href="/profile">
                  <a className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Profil
                  </a>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem
                className="text-red-600 focus:text-red-600"
                onClick={() => logoutMutation.mutate()}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Çıkış Yap
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}