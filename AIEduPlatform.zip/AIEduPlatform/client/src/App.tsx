import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DiscoverPage from "@/pages/discover-page";
import AILearningPage from "@/pages/ai-learning-page";
import CommunitiesPage from "@/pages/communities-page";
import CompetitionsPage from "@/pages/competitions-page";
import LibraryPage from "@/pages/library-page";
import CoursesPage from "@/pages/courses-page";
import ProfilePage from "@/pages/profile-page";
import CreateVideoPage from "@/pages/create-video-page";
import UploadEbookPage from "@/pages/upload-ebook-page";
import Navigation from "@/components/ui/navigation";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={DiscoverPage} />
      <ProtectedRoute path="/discover" component={DiscoverPage} />
      <ProtectedRoute path="/ai-learning" component={AILearningPage} />
      <ProtectedRoute path="/communities" component={CommunitiesPage} />
      <ProtectedRoute path="/competitions" component={CompetitionsPage} />
      <ProtectedRoute path="/library" component={LibraryPage} />
      <ProtectedRoute path="/courses" component={CoursesPage} />
      <ProtectedRoute path="/profile" component={ProfilePage} />
      <ProtectedRoute path="/create-video" component={CreateVideoPage} />
      <ProtectedRoute path="/upload-ebook" component={UploadEbookPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Navigation />
        <main className="container mx-auto px-4 py-8">
          <Router />
        </main>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;